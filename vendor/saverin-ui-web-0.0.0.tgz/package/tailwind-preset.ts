import type { Config } from 'tailwindcss';

// Saverin DS Tailwind preset.
// Maps the generated CSS custom properties (@saverin/tokens/css) onto Tailwind
// utilities so components stay token-driven. Apps add this to `presets` and add
// the ui-web source to their `content` globs. Brand/theme swap happens at runtime
// via the data-brand / data-theme attributes on <html>, not in the build.

const preset: Partial<Config> = {
  theme: {
    extend: {
      colors: {
        bg: {
          page: 'var(--color-bg-page)',
          subtle: 'var(--color-bg-subtle)',
          muted: 'var(--color-bg-muted)',
          inverse: 'var(--color-bg-inverse)',
        },
        surface: {
          card: 'var(--color-surface-card)',
          'card-subtle': 'var(--color-surface-card-subtle)',
          overlay: 'var(--color-surface-overlay)',
          pressed: 'var(--color-surface-pressed)',
          disabled: 'var(--color-surface-disabled)',
        },
        content: {
          primary: 'var(--color-text-primary)',
          secondary: 'var(--color-text-secondary)',
          tertiary: 'var(--color-text-tertiary)',
          disabled: 'var(--color-text-disabled)',
          inverse: 'var(--color-text-inverse)',
          'on-accent': 'var(--color-text-on-accent)',
          brand: 'var(--color-text-brand)',
        },
        stroke: {
          subtle: 'var(--color-border-subtle)',
          DEFAULT: 'var(--color-border-default)',
          strong: 'var(--color-border-strong)',
          'on-color': 'var(--color-border-on-color)',
        },
        accent: {
          brand: 'var(--color-accent-brand)',
          'brand-subtle': 'var(--color-accent-brand-subtle)',
          danger: 'var(--color-accent-danger)',
          'danger-subtle': 'var(--color-accent-danger-subtle)',
          warning: 'var(--color-accent-warning)',
          'warning-subtle': 'var(--color-accent-warning-subtle)',
          info: 'var(--color-accent-info)',
          sienna: 'var(--color-accent-sienna)',
          success: 'var(--color-accent-success)',
          'success-subtle': 'var(--color-accent-success-subtle)',
        },
        button: {
          'primary-bg': 'var(--color-button-primary-bg)',
          'primary-text': 'var(--color-button-primary-text)',
          'secondary-bg': 'var(--color-button-secondary-bg)',
          'secondary-text': 'var(--color-button-secondary-text)',
          'ghost-bg': 'var(--color-button-ghost-bg)',
          'ghost-text': 'var(--color-button-ghost-text)',
        },
        knob: 'var(--color-control-knob)',
      },
      borderRadius: {
        none: 'var(--radius-none)',
        xs: 'var(--radius-xs)',
        sm: 'var(--radius-sm)',
        md: 'var(--radius-md)',
        lg: 'var(--radius-lg)',
        xl: 'var(--radius-xl)',
        '2xl': 'var(--radius-2xl)',
        '3xl': 'var(--radius-3xl)',
        full: 'var(--radius-full)',
      },
      fontFamily: {
        brand: ['var(--brand-font-family)', 'ui-rounded', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        // DS text scale (size / line-height). Weight is set per component.
        'label-s': ['15px', '20px'],
        'label-m': ['17px', '22px'],
        'label-l': ['19px', '24px'],
        'body-s': ['15px', '20px'],
        'body-m': ['16px', '24px'],
        'body-l': ['18px', '28px'],
        'heading-s': ['20px', '28px'],
        'heading-m': ['28px', '36px'],
        'heading-l': ['32px', '40px'],
        'heading-xl': ['40px', '48px'],
      },
    },
  },
};

export default preset;
