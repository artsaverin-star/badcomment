import { forwardRef, type HTMLAttributes, type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from './cn';

// Figma atom "Header": title + optional description, flex-col. Sizes scale the title kegль and gap.
// XS title Body/M Semibold 17/22, desc Caption 12/16; S ~22/28; M Heading/L 28/34 -0.3, desc 17/22;
// L Heading/XL 34/41 -0.4, desc 17/22; XL Display/XL 48/52 -0.5, desc Body/L 20/25.
// Title = text-primary, description = text-secondary.
const headerTitleVariants = cva('font-bold [font-family:var(--brand-font-family)] text-[var(--color-text-primary)]', {
  variants: {
    size: {
      XS: 'text-[17px] leading-[22px] font-semibold',
      S: 'text-[22px] leading-[28px] tracking-[-0.2px]',
      M: 'text-[28px] leading-[34px] tracking-[-0.3px]',
      L: 'text-[34px] leading-[41px] tracking-[-0.4px]',
      XL: 'text-[48px] leading-[52px] tracking-[-0.5px]',
    },
  },
  defaultVariants: { size: 'M' },
});

const headerWrapVariants = cva('flex flex-col', {
  variants: {
    size: {
      XS: 'gap-1',
      S: 'gap-1.5',
      M: 'gap-1.5',
      L: 'gap-2',
      XL: 'gap-3',
    },
  },
  defaultVariants: { size: 'M' },
});

const headerDescVariants = cva('[font-family:var(--brand-font-family)] text-[var(--color-text-secondary)]', {
  variants: {
    size: {
      XS: 'text-[12px] leading-[16px]',
      S: 'text-[17px] leading-[22px]',
      M: 'text-[17px] leading-[22px]',
      L: 'text-[17px] leading-[22px]',
      XL: 'text-[20px] leading-[25px]',
    },
  },
  defaultVariants: { size: 'M' },
});

export interface HeaderProps
  extends Omit<HTMLAttributes<HTMLDivElement>, 'title'>,
    VariantProps<typeof headerWrapVariants> {
  title: ReactNode;
  description?: ReactNode;
  as?: 'h1' | 'h2' | 'h3' | 'h4';
}

export const Header = forwardRef<HTMLDivElement, HeaderProps>(function Header(
  { className, size, title, description, as: Title = 'h2', ...props },
  ref,
) {
  return (
    <div ref={ref} className={cn(headerWrapVariants({ size }), className)} {...props}>
      <Title className={headerTitleVariants({ size })}>{title}</Title>
      {description && <p className={headerDescVariants({ size })}>{description}</p>}
    </div>
  );
});
