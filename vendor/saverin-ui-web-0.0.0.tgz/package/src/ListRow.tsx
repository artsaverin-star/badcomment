import { forwardRef, type HTMLAttributes, type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from './cn';

// Figma atom "ListRow" (1439:6492): flex gap-12 items-start; icon container vertically centered
// on the first text line + Body/M 17/22 text-secondary. S icon16/text15/20, L icon24/text20/25.
const listRowTextVariants = cva(
  '[font-family:var(--brand-font-family)] font-normal text-[var(--color-text-secondary)]',
  {
    variants: {
      size: {
        S: 'text-[15px] leading-[20px]',
        M: 'text-[17px] leading-[22px]',
        L: 'text-[20px] leading-[25px]',
      },
    },
    defaultVariants: { size: 'M' },
  },
);

const listRowIconVariants = cva(
  'flex shrink-0 items-center text-[var(--color-text-secondary)]',
  {
    variants: {
      size: {
        S: 'h-[20px] [&_svg]:size-4',
        M: 'h-[22px] [&_svg]:size-5',
        L: 'h-[25px] [&_svg]:size-6',
      },
    },
    defaultVariants: { size: 'M' },
  },
);

export interface ListRowProps
  extends HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof listRowTextVariants> {
  icon?: ReactNode;
  children: ReactNode;
}

export const ListRow = forwardRef<HTMLDivElement, ListRowProps>(function ListRow(
  { className, size, icon, children, ...props },
  ref,
) {
  return (
    <div ref={ref} className={cn('flex items-start gap-3', className)} {...props}>
      {icon && <span className={listRowIconVariants({ size })}>{icon}</span>}
      <p className={listRowTextVariants({ size })}>{children}</p>
    </div>
  );
});
