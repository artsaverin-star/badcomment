import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from './cn';

// Figma atom "IconButton" (1289:6540): square, rounded-lg(16), same 4 color variants as Button.
// Sizes S/M/L = 32/40/56px; icons 16/20/24; padding 8/10/16. Self-contained var() classes
// so it works under both Tailwind v3 and v4 without the preset.
const iconButtonVariants = cva(
  'inline-flex items-center justify-center shrink-0 select-none rounded-[var(--radius-lg)] ' +
    'transition-colors outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-accent-brand)] ' +
    'disabled:bg-[var(--color-surface-disabled)] disabled:text-[var(--color-text-disabled)] ' +
    'disabled:border-transparent disabled:cursor-not-allowed disabled:pointer-events-none',
  {
    variants: {
      variant: {
        primary:
          'bg-[var(--color-button-primary-bg)] text-[var(--color-button-primary-text)] hover:opacity-90 active:opacity-80',
        secondary:
          'bg-[var(--color-button-secondary-bg)] text-[var(--color-button-secondary-text)] ' +
          'border border-[var(--color-border-default)] hover:bg-[var(--color-surface-pressed)] active:bg-[var(--color-surface-pressed)]',
        ghost:
          'bg-transparent text-[var(--color-button-ghost-text)] hover:bg-[var(--color-surface-card-subtle)] active:bg-[var(--color-surface-pressed)]',
        danger:
          'bg-[var(--color-accent-danger)] text-[var(--color-text-on-accent)] hover:opacity-90 active:opacity-80',
      },
      size: {
        S: 'size-8 [&_svg]:size-4',
        M: 'size-10 [&_svg]:size-5',
        L: 'size-14 [&_svg]:size-6',
      },
    },
    defaultVariants: { variant: 'primary', size: 'M' },
  },
);

export interface IconButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof iconButtonVariants> {
  icon: ReactNode;
  'aria-label': string;
}

export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(function IconButton(
  { className, variant, size, icon, type = 'button', ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      className={cn(iconButtonVariants({ variant, size }), className)}
      {...props}
    >
      {icon}
    </button>
  );
});

export { iconButtonVariants };
