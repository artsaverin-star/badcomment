import { forwardRef, type HTMLAttributes, type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from './cn';

// Figma atom "TextBlock" (1586:1664): title + optional description, contrast by weight (same kegль).
// M both 17/22 — title Semibold/text-primary, desc Regular/text-secondary, gap 2px. S=15/20, L=20/25.
const textBlockTitleVariants = cva(
  '[font-family:var(--brand-font-family)] font-semibold text-[var(--color-text-primary)]',
  {
    variants: {
      size: {
        S: 'text-[15px] leading-[20px]',
        M: 'text-[17px] leading-[22px]',
        L: 'text-[20px] leading-[25px]',
      },
    },
    defaultVariants: { size: 'M' },
  },
);

const textBlockDescVariants = cva(
  '[font-family:var(--brand-font-family)] font-normal text-[var(--color-text-secondary)]',
  {
    variants: {
      size: {
        S: 'text-[15px] leading-[20px]',
        M: 'text-[17px] leading-[22px]',
        L: 'text-[20px] leading-[25px]',
      },
    },
    defaultVariants: { size: 'M' },
  },
);

export interface TextBlockProps
  extends Omit<HTMLAttributes<HTMLDivElement>, 'title'>,
    VariantProps<typeof textBlockTitleVariants> {
  title: ReactNode;
  description?: ReactNode;
}

export const TextBlock = forwardRef<HTMLDivElement, TextBlockProps>(function TextBlock(
  { className, size, title, description, ...props },
  ref,
) {
  return (
    <div ref={ref} className={cn('flex flex-col gap-0.5', className)} {...props}>
      <span className={textBlockTitleVariants({ size })}>{title}</span>
      {description && <span className={textBlockDescVariants({ size })}>{description}</span>}
    </div>
  );
});
