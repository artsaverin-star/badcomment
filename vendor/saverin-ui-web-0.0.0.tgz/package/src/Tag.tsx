import { forwardRef, type HTMLAttributes, type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from './cn';

// Figma atom "Tag": rounded-full, Label/M Medium 13/16, gap-4, optional iconLeft (14px) + closable X.
// Tones neutral/brand/info/warning/danger × sizes S/M/L (heights 22/32/44).
const tagVariants = cva(
  'inline-flex items-center gap-1 [font-family:var(--brand-font-family)] font-medium ' +
    'whitespace-nowrap select-none rounded-full',
  {
    variants: {
      tone: {
        neutral: 'bg-[var(--color-bg-muted)] text-[var(--color-text-primary)]',
        brand: 'bg-[var(--color-accent-brand)] text-[var(--color-button-primary-text)]',
        info: 'bg-[var(--color-accent-info)] text-[var(--color-text-on-accent)]',
        warning: 'bg-[var(--color-accent-warning)] text-[var(--color-text-on-accent)]',
        danger: 'bg-[var(--color-accent-danger)] text-[var(--color-text-on-accent)]',
      },
      size: {
        S: 'h-[22px] px-2 text-[11px] leading-[14px]',
        M: 'h-8 px-3 text-[13px] leading-[16px]',
        L: 'h-11 px-4 text-[15px] leading-[20px]',
      },
    },
    defaultVariants: { tone: 'neutral', size: 'M' },
  },
);

export interface TagProps
  extends HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof tagVariants> {
  iconLeft?: ReactNode;
  onClose?: () => void;
}

export const Tag = forwardRef<HTMLSpanElement, TagProps>(function Tag(
  { className, tone, size, iconLeft, onClose, children, ...props },
  ref,
) {
  return (
    <span ref={ref} className={cn(tagVariants({ tone, size }), className)} {...props}>
      {iconLeft && (
        <span className="inline-flex shrink-0 items-center [&_svg]:size-3.5">{iconLeft}</span>
      )}
      {children}
      {onClose && (
        <button
          type="button"
          onClick={onClose}
          aria-label="Remove"
          className="inline-flex shrink-0 items-center opacity-70 transition-opacity hover:opacity-100 [&_svg]:size-4"
        >
          <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path
              d="M4 4l8 8M12 4l-8 8"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
          </svg>
        </button>
      )}
    </span>
  );
});

export { tagVariants };
