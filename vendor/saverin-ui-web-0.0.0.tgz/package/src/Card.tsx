import { forwardRef, type HTMLAttributes } from 'react';
import { cn } from './cn';

// Figma atom "Card" (942:1235): surface-card bg, 1px glass-highlight border (rgba 255,255,255,0.5),
// Elevation/Raised shadow, gap space/20, p space/32, rounded-3xl(32). Generic content container.
export interface CardProps extends HTMLAttributes<HTMLDivElement> {}

export const Card = forwardRef<HTMLDivElement, CardProps>(function Card(
  { className, children, ...props },
  ref,
) {
  return (
    <div
      ref={ref}
      className={cn(
        'flex flex-col gap-5 rounded-[var(--radius-3xl)] p-8 bg-[var(--color-surface-card)] ' +
          'border border-[rgba(255,255,255,0.5)] ' +
          'shadow-[0_1px_2px_0_rgba(0,0,0,0.06),0_4px_8px_0_rgba(0,0,0,0.04)]',
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
});
