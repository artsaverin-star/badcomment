import { forwardRef, type HTMLAttributes, type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from './cn';

// Figma atom "Quote" (1521:6375): flex gap-12 items-start; a 3px self-stretch rounded bar
// (border-strong) + Body/M 17/22 text-primary. S=15/20, L=20/25.
const quoteTextVariants = cva(
  '[font-family:var(--brand-font-family)] font-normal text-[var(--color-text-primary)]',
  {
    variants: {
      size: {
        S: 'text-[15px] leading-[20px]',
        M: 'text-[17px] leading-[22px]',
        L: 'text-[20px] leading-[25px]',
      },
    },
    defaultVariants: { size: 'M' },
  },
);

export interface QuoteProps
  extends HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof quoteTextVariants> {
  children: ReactNode;
}

export const Quote = forwardRef<HTMLDivElement, QuoteProps>(function Quote(
  { className, size, children, ...props },
  ref,
) {
  return (
    <div ref={ref} className={cn('flex items-stretch gap-3', className)} {...props}>
      <div className="w-[3px] shrink-0 self-stretch rounded-full bg-[var(--color-border-strong)]" />
      <p className={quoteTextVariants({ size })}>{children}</p>
    </div>
  );
});
