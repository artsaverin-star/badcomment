import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from './cn';

// Mirrors Figma atom "Button" (node 575:7277): variant primary/secondary/ghost/danger,
// size S/M/L = 32/40/56px. Figma states default/hover/pressed/disabled map to the CSS
// pseudo-classes here. Classes reference @saverin/tokens CSS vars directly (arbitrary
// values) so the component is self-contained — no Tailwind preset required, works in v3 and v4.
const buttonVariants = cva(
  'inline-flex items-center justify-center gap-2 [font-family:var(--brand-font-family)] font-semibold ' +
    'whitespace-nowrap select-none rounded-[var(--radius-lg)] transition-colors outline-none ' +
    'focus-visible:ring-2 focus-visible:ring-[var(--color-accent-brand)] ' +
    'disabled:bg-[var(--color-surface-disabled)] disabled:text-[var(--color-text-disabled)] ' +
    'disabled:border-transparent disabled:cursor-not-allowed disabled:pointer-events-none',
  {
    variants: {
      variant: {
        primary:
          'bg-[var(--color-button-primary-bg)] text-[var(--color-button-primary-text)] hover:opacity-90 active:opacity-80',
        secondary:
          'bg-[var(--color-button-secondary-bg)] text-[var(--color-button-secondary-text)] ' +
          'border border-[var(--color-border-default)] hover:bg-[var(--color-surface-pressed)] active:bg-[var(--color-surface-pressed)]',
        ghost:
          'bg-transparent text-[var(--color-button-ghost-text)] hover:bg-[var(--color-surface-card-subtle)] active:bg-[var(--color-surface-pressed)]',
        danger:
          'bg-[var(--color-accent-danger)] text-[var(--color-text-on-accent)] hover:opacity-90 active:opacity-80',
      },
      size: {
        S: 'h-8 px-3 text-[15px] leading-[20px]',
        M: 'h-10 px-4 text-[17px] leading-[22px]',
        L: 'h-14 px-5 text-[20px] leading-[25px]',
      },
    },
    defaultVariants: { variant: 'primary', size: 'M' },
  },
);

export interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  iconStart?: ReactNode;
  iconEnd?: ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { className, variant, size, iconStart, iconEnd, children, type = 'button', ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    >
      {iconStart && (
        <span className="inline-flex shrink-0 items-center [&_svg]:size-5">{iconStart}</span>
      )}
      {children}
      {iconEnd && (
        <span className="inline-flex shrink-0 items-center [&_svg]:size-5">{iconEnd}</span>
      )}
    </button>
  );
});

export { buttonVariants };
